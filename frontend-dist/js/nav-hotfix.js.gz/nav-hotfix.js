(function () {
  "use strict";

  var routes = [
    { key: "dashboard", path: "/dashboard", icon: "images" },
    { key: "customerConfig", path: "/customerConfig", icon: "user" },
    { key: "systemConfig", path: "/systemConfig", icon: "cogs" },
    { key: "upload", path: "/", icon: "upload" }
  ];

  var labels = {
    "zh-CN": {
      dashboard: "文件管理",
      customerConfig: "用户管理",
      systemConfig: "系统设置",
      upload: "文件上传",
      more: "更多",
      uploadSettings: "上传设置",
      linkFormat: "链接格式",
      manage: "系统管理",
      logout: "退出登录",
      trash: "回收站",
      importTelegram: "导入 Telegram",
      close: "关闭",
      restore: "恢复",
      permanentDelete: "永久删除",
      open: "打开",
      loading: "加载中",
      refresh: "刷新",
      noFiles: "暂无文件",
      imported: "已导入",
      skipped: "已跳过",
      failed: "失败",
      importingTelegram: "正在导入 Telegram...",
      importDone: "Telegram 导入完成",
      restoreSelected: "恢复选中",
      restoreDone: "已恢复",
      selectFilesFirst: "请先选择文件",
      dashboardUnavailable: "文件管理界面尚未就绪"
    },
    en: {
      dashboard: "Files",
      customerConfig: "Users",
      systemConfig: "Settings",
      upload: "Upload",
      more: "More",
      uploadSettings: "Upload Settings",
      linkFormat: "Link Format",
      manage: "Manage",
      logout: "Logout",
      trash: "Trash",
      importTelegram: "Import Telegram",
      close: "Close",
      restore: "Restore",
      permanentDelete: "Delete Forever",
      open: "Open",
      loading: "Loading",
      refresh: "Refresh",
      noFiles: "No files",
      imported: "Imported",
      skipped: "Skipped",
      failed: "Failed",
      importingTelegram: "Importing Telegram...",
      importDone: "Telegram import complete",
      restoreSelected: "Restore Selected",
      restoreDone: "Restored",
      selectFilesFirst: "Select files first",
      dashboardUnavailable: "File manager is not ready"
    }
  };

  var icons = {
    images: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v13a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 18.5v-13Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="m6 17 3.5-4 2.5 2.5 3.5-4.5L20 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="8" r="1.4" fill="currentColor"/></svg>',
    user: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10" cy="8" r="3.2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 20a6 6 0 0 1 12 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M18.5 10v5M16 12.5h5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    cogs: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M18.5 5.5l-1.7 1.7M7.2 16.8l-1.7 1.7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    upload: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="m7.5 8.5 4.5-4.5 4.5 4.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 15v3.5A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5V15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    more: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.7" fill="currentColor"/><circle cx="12" cy="12" r="1.7" fill="currentColor"/><circle cx="19" cy="12" r="1.7" fill="currentColor"/></svg>',
    link: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.1 0l1.4-1.4a5 5 0 0 0-7.1-7.1L10.5 5.4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M14 11a5 5 0 0 0-7.1 0l-1.4 1.4a5 5 0 0 0 7.1 7.1l.9-.9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    logout: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M16 17l5-5-5-5M21 12H9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    trash: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M7 6l1 15h8l1-15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    telegram: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 4 3.7 10.8c-1 .4-.9 1.9.2 2.1l4.5.9 1.7 5.1c.3.9 1.5 1.1 2.1.3l2.5-3.2 4.2 3.1c.8.6 2 .1 2.2-.9L23 5.5c.2-1-.9-1.8-2-1.5Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="m8.5 13.8 7.1-5.1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    restore: '<svg class="cfib-nav-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7v6h6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.3 13A7 7 0 1 0 7 5.8L4 8.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  var dashboardModeStorageKey = "cfib-dashboard-mode";
  var dashboardRefreshStorageKey = "cfib-dashboard-refresh-pending";
  var pendingDashboardMode = "";
  var currentDashboardMode = "";
  var dashboardModeEnforcePending = false;

  function locale() {
    return localStorage.getItem("app-locale") === "en" ? "en" : "zh-CN";
  }

  function text(key) {
    return labels[locale()][key] || labels["zh-CN"][key] || key;
  }

  function normalizedPath() {
    var path = window.location.pathname.replace(/\/+$/, "");
    return path || "/";
  }

  function activeKey() {
    var path = normalizedPath();
    var match = routes.find(function (route) {
      return route.path === path;
    });
    return match ? match.key : "";
  }

  function makeNav(className, includeActions) {
    var nav = document.createElement("nav");
    nav.className = "cfib-main-nav " + className;
    nav.setAttribute("aria-label", "Main navigation");

    routes.forEach(function (route) {
      var item = document.createElement("a");
      item.className = "cfib-nav-item";
      item.dataset.routeKey = route.key;
      item.href = route.path;
      item.innerHTML = icons[route.icon] + '<span class="cfib-nav-label"></span>';
      item.addEventListener("click", function (event) {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        if (route.key === "dashboard") {
          openNormalFileView();
          return;
        }
        if (normalizedPath() !== route.path) {
          window.history.pushState({}, "", route.path);
          window.dispatchEvent(new Event("popstate"));
        }
      });
      nav.appendChild(item);
    });

    if (includeActions) {
      nav.appendChild(makeUploadActions());
    }

    return nav;
  }

  function makeUploadActions() {
    var wrap = document.createElement("div");
    wrap.className = "cfib-upload-actions";
    wrap.innerHTML =
      '<button class="cfib-actions-trigger" type="button" aria-expanded="false">' +
      icons.more + '<span class="cfib-nav-label" data-label="more"></span></button>' +
      '<div class="cfib-upload-actions-panel" role="menu">' +
      '<button class="cfib-action-item" type="button" data-action="settings" role="menuitem">' + icons.upload + '<span data-label="uploadSettings"></span></button>' +
      '<button class="cfib-action-item" type="button" data-action="link" role="menuitem">' + icons.link + '<span data-label="linkFormat"></span></button>' +
      '<button class="cfib-action-item" type="button" data-action="manage" role="menuitem">' + icons.cogs + '<span data-label="manage"></span></button>' +
      '<button class="cfib-action-item" type="button" data-action="logout" role="menuitem">' + icons.logout + '<span data-label="logout"></span></button>' +
      '</div>';

    var trigger = wrap.querySelector(".cfib-actions-trigger");
    trigger.addEventListener("click", function (event) {
      event.stopPropagation();
      var isOpen = !wrap.classList.contains("is-open");
      closeActionMenus();
      wrap.classList.toggle("is-open", isOpen);
      trigger.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) positionActionPanel(wrap);
    });

    wrap.querySelectorAll("[data-action]").forEach(function (button) {
      button.addEventListener("click", function (event) {
        event.stopPropagation();
        closeActionMenus();
        runUploadAction(button.dataset.action);
      });
    });

    return wrap;
  }

  function makeAdminActions() {
    var wrap = document.createElement("div");
    wrap.className = "cfib-admin-actions";
    var actions = [
      { key: "trash", icon: icons.trash }
    ];

    actions.forEach(function (action) {
      var button = document.createElement("button");
      button.className = "cfib-admin-action-btn";
      button.type = "button";
      button.dataset.adminAction = action.key;
      button.innerHTML = action.icon + '<span class="cfib-nav-label" data-label="' + (action.label || action.key) + '"></span>';
      button.title = text(action.label || action.key);
      button.setAttribute("aria-label", text(action.label || action.key));
      button.addEventListener("click", function (event) {
        event.stopPropagation();
        closeActionMenus();
        runAdminAction(action.key);
      });
      wrap.appendChild(button);
    });

    return wrap;
  }

  function updateNav(nav) {
    var current = activeKey();
    var trashViewActive = current === "dashboard" && isTrashViewActive();
    nav.querySelectorAll(".cfib-nav-item").forEach(function (item) {
      var key = item.dataset.routeKey;
      var itemActive = key === current && !(key === "dashboard" && trashViewActive);
      item.classList.toggle("is-active", itemActive);
      item.setAttribute("aria-current", itemActive ? "page" : "false");
      var label = item.querySelector(".cfib-nav-label");
      if (label) label.textContent = text(key);
    });
    nav.querySelectorAll("[data-label]").forEach(function (node) {
      node.textContent = text(node.dataset.label);
    });
  }

  function closeActionMenus() {
    document.querySelectorAll(".cfib-upload-actions.is-open").forEach(function (wrap) {
      wrap.classList.remove("is-open");
      var trigger = wrap.querySelector(".cfib-actions-trigger");
      if (trigger) trigger.setAttribute("aria-expanded", "false");
      var panel = wrap.querySelector(".cfib-upload-actions-panel");
      if (panel) {
        panel.style.left = "";
        panel.style.top = "";
      }
    });
  }

  function positionActionPanel(wrap) {
    var trigger = wrap.querySelector(".cfib-actions-trigger");
    var panel = wrap.querySelector(".cfib-upload-actions-panel");
    if (!trigger || !panel) return;

    var triggerRect = trigger.getBoundingClientRect();
    var panelRect = panel.getBoundingClientRect();
    var margin = 8;
    var panelWidth = panelRect.width || 180;
    var left = Math.min(
      window.innerWidth - panelWidth - margin,
      Math.max(margin, triggerRect.right - panelWidth)
    );
    var top = Math.min(
      window.innerHeight - margin,
      triggerRect.bottom + margin
    );

    panel.style.left = left + "px";
    panel.style.top = top + "px";
  }

  function positionOpenActionMenus() {
    document.querySelectorAll(".cfib-upload-actions.is-open").forEach(positionActionPanel);
  }

  function clickQuickToolbarButton(index) {
    var buttons = document.querySelectorAll(".quick-toolbar .quick-toolbar-button");
    if (!buttons[index]) return false;
    buttons[index].click();
    return true;
  }

  function runUploadAction(action) {
    if (action === "settings") {
      clickQuickToolbarButton(3);
      return;
    }
    if (action === "link") {
      clickQuickToolbarButton(2);
      return;
    }
    if (action === "manage") {
      window.history.pushState({}, "", "/dashboard");
      window.dispatchEvent(new Event("popstate"));
      return;
    }
    if (action === "logout") {
      fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ authType: "user" })
      }).finally(function () {
        window.history.pushState({}, "", "/login");
        window.dispatchEvent(new Event("popstate"));
      });
    }
  }

  function runAdminAction(action) {
    if (action === "trash") {
      openTrashView();
    }
  }

  function makeFileModeActions() {
    var wrap = document.createElement("div");
    wrap.className = "cfib-file-mode-actions";
    var actions = [
      { key: "importTelegram", icon: icons.telegram, label: "importTelegram" },
      { key: "restoreTrash", icon: icons.restore, label: "restoreSelected" }
    ];

    actions.forEach(function (action) {
      var button = document.createElement("button");
      button.className = "cfib-file-mode-btn";
      button.type = "button";
      button.dataset.fileModeAction = action.key;
      button.title = text(action.label);
      button.setAttribute("aria-label", text(action.label));
      button.innerHTML = action.icon + '<span class="cfib-file-mode-label" data-label="' + action.label + '"></span>';
      button.addEventListener("click", function (event) {
        event.stopPropagation();
        runFileModeAction(action.key);
      });
      wrap.appendChild(button);
    });

    return wrap;
  }

  function runFileModeAction(action) {
    if (action === "importTelegram") {
      importTelegramUpdates();
      return;
    }
    if (action === "restoreTrash") {
      restoreSelectedTrashFiles();
    }
  }

  function ensureDashboardFileActions() {
    var existing = document.querySelector(".cfib-file-mode-actions");
    if (normalizedPath() !== "/dashboard") {
      if (existing) existing.remove();
      return;
    }

    var host = document.querySelector(".breadcrumb-container");
    if (!host) return;

    if (!existing || !host.contains(existing)) {
      if (existing) existing.remove();
      existing = makeFileModeActions();
      var statsBadge = host.querySelector(".stats-badge");
      if (statsBadge) {
        host.insertBefore(existing, statsBadge);
      } else {
        host.appendChild(existing);
      }
    }

    updateFileModeActions(existing);
  }

  function updateFileModeActions(wrap) {
    var proxy = findDashboardProxy();
    var trashMode = isTrashMode(proxy);
    var selectedCount = proxy && Array.isArray(proxy.selectedFiles) ? proxy.selectedFiles.filter(function (file) {
      return file && !file.isFolder;
    }).length : 0;

    if (proxy) patchDashboardTrashDelete(proxy);

    wrap.querySelectorAll("[data-file-mode-action]").forEach(function (button) {
      var action = button.dataset.fileModeAction;
      var labelKey = action === "restoreTrash" ? "restoreSelected" : action;
      button.title = text(labelKey);
      button.setAttribute("aria-label", text(labelKey));
      button.hidden = action === "restoreTrash" && !trashMode;
      button.disabled = action === "restoreTrash" && selectedCount === 0;
    });

    wrap.querySelectorAll("[data-label]").forEach(function (node) {
      node.textContent = text(node.dataset.label);
    });
  }

  function findDashboardProxy() {
    var nodes = document.querySelectorAll(".container, .main-container, .breadcrumb-container, #app *");
    for (var index = 0; index < nodes.length; index += 1) {
      var instance = nodes[index].__vueParentComponent;
      while (instance) {
        if (instance.proxy && typeof instance.proxy.refreshFileList === "function" && typeof instance.proxy.fetchFileList === "function") {
          return instance.proxy;
        }
        instance = instance.parent;
      }
    }
    return null;
  }

  function getSessionValue(key) {
    try {
      return window.sessionStorage.getItem(key) || "";
    } catch (error) {
      return "";
    }
  }

  function setSessionValue(key, value) {
    try {
      window.sessionStorage.setItem(key, value);
    } catch (error) {
      // Ignore unavailable session storage; in-memory state still covers the active page.
    }
  }

  function removeSessionValue(key) {
    try {
      window.sessionStorage.removeItem(key);
    } catch (error) {
      // Ignore unavailable session storage.
    }
  }

  function navigateToDashboard() {
    if (normalizedPath() !== "/dashboard") {
      window.history.pushState({}, "", "/dashboard");
      window.dispatchEvent(new Event("popstate"));
    }
  }

  function requestDashboardMode(mode) {
    pendingDashboardMode = mode;
    currentDashboardMode = mode;
    setSessionValue(dashboardModeStorageKey, mode);
    navigateToDashboard();
    applyPendingDashboardMode();
    scheduleRefresh();
  }

  function applyDashboardMode(proxy, mode) {
    currentDashboardMode = mode;
    patchDashboardTrashDelete(proxy);
    patchDashboardModeRefresh(proxy);
    resetDashboardSearch(proxy);

    proxy.filters = mode === "trash" ? trashDashboardFilters() : emptyDashboardFilters();
    proxy.currentPath = "";
    return proxy.refreshFileList();
  }

  function applyPendingDashboardMode() {
    if (normalizedPath() !== "/dashboard") return;

    var proxy = findDashboardProxy();
    if (!proxy) return;

    patchDashboardTrashDelete(proxy);
    patchDashboardModeRefresh(proxy);
    var mode = pendingDashboardMode || getSessionValue(dashboardModeStorageKey);
    if (!mode) return;

    pendingDashboardMode = "";
    removeSessionValue(dashboardModeStorageKey);
    applyDashboardMode(proxy, mode);
  }

  function refreshDashboardIfReady() {
    if (normalizedPath() !== "/dashboard") return false;

    var proxy = findDashboardProxy();
    if (!proxy) return false;

    patchDashboardTrashDelete(proxy);
    patchDashboardModeRefresh(proxy);
    forceDashboardModeFilters(proxy);
    proxy.refreshFileList();
    return true;
  }

  function markDashboardRefreshPending() {
    setSessionValue(dashboardRefreshStorageKey, "1");
  }

  function flushPendingDashboardRefresh() {
    if (normalizedPath() !== "/dashboard") return;
    if (getSessionValue(dashboardRefreshStorageKey) !== "1") return;

    if (refreshDashboardIfReady()) {
      removeSessionValue(dashboardRefreshStorageKey);
    }
  }

  function emptyDashboardFilters() {
    return {
      accessStatus: [],
      listType: [],
      label: [],
      fileType: [],
      channel: [],
      channelName: []
    };
  }

  function trashDashboardFilters(baseFilters) {
    var filters = Object.assign(emptyDashboardFilters(), baseFilters || {});
    filters.listType = ["Trash"];
    return filters;
  }

  function forceDashboardModeFilters(proxy) {
    if (!proxy || currentDashboardMode !== "trash") return;
    proxy.filters = trashDashboardFilters(proxy.filters);
    proxy.currentPath = "";
  }

  function hasNonTrashRows(proxy) {
    var rows = proxy && Array.isArray(proxy.tableData) ? proxy.tableData : [];
    return rows.some(function (file) {
      return file && !file.isFolder && file.metadata && file.metadata.ListType !== "Trash";
    });
  }

  function patchDashboardModeRefresh(proxy) {
    if (!proxy) return;
    if (proxy.__cfibModeRefreshPatched) {
      forceDashboardModeFilters(proxy);
      return;
    }

    proxy.__cfibModeRefreshPatched = true;
    proxy.__cfibOriginalRefreshFileList = proxy.refreshFileList;
    proxy.refreshFileList = function () {
      if (currentDashboardMode === "trash") forceDashboardModeFilters(proxy);
      var result = proxy.__cfibOriginalRefreshFileList.apply(proxy, arguments);
      if (result && typeof result.then === "function") {
        return result.then(function (value) {
          if (currentDashboardMode === "trash") forceDashboardModeFilters(proxy);
          return value;
        });
      }
      if (currentDashboardMode === "trash") forceDashboardModeFilters(proxy);
      return result;
    };

    forceDashboardModeFilters(proxy);
  }

  function enforceDashboardModeRefresh() {
    if (normalizedPath() !== "/dashboard" || currentDashboardMode !== "trash") return;

    var proxy = findDashboardProxy();
    if (!proxy) return;

    patchDashboardTrashDelete(proxy);
    patchDashboardModeRefresh(proxy);
    forceDashboardModeFilters(proxy);

    if (dashboardModeEnforcePending || !hasNonTrashRows(proxy)) return;

    dashboardModeEnforcePending = true;
    Promise.resolve(proxy.refreshFileList()).finally(function () {
      dashboardModeEnforcePending = false;
    });
  }

  function resetDashboardSearch(proxy) {
    proxy.tempSearch = "";
    proxy.search = "";
    proxy.searchKeywords = "";
    proxy.searchIncludeTags = "";
    proxy.searchExcludeTags = "";
    proxy.isSearchMode = false;
    proxy.currentPage = 1;
    if (Array.isArray(proxy.selectedFiles)) proxy.selectedFiles = [];
  }

  function openNormalFileView() {
    requestDashboardMode("normal");
  }

  function openTrashView() {
    requestDashboardMode("trash");
  }

  function isTrashMode(proxy) {
    return Boolean(proxy && proxy.filters && Array.isArray(proxy.filters.listType) && proxy.filters.listType.indexOf("Trash") !== -1);
  }

  function isTrashViewActive() {
    return currentDashboardMode === "trash" || pendingDashboardMode === "trash" || getSessionValue(dashboardModeStorageKey) === "trash" || isTrashMode(findDashboardProxy());
  }

  function patchDashboardTrashDelete(proxy) {
    if (proxy.__cfibTrashDeletePatched) return;
    proxy.__cfibTrashDeletePatched = true;
    proxy.__cfibOriginalHandleDelete = proxy.handleDelete;
    proxy.__cfibOriginalHandleBatchDelete = proxy.handleBatchDelete;

    proxy.handleDelete = function (index, fileId) {
      if (!isTrashMode(proxy)) {
        return proxy.__cfibOriginalHandleDelete.apply(proxy, arguments);
      }
      if (!window.confirm(text("permanentDelete") + ": " + fileId)) return;
      apiJson("/api/manage/delete/" + encodeManagePath(fileId) + "?permanent=true", { method: "DELETE" })
        .then(function () {
          return proxy.refreshFileList();
        })
        .catch(function (error) {
          showToast(error.message || String(error), "error");
        });
    };

    proxy.handleBatchDelete = function () {
      if (!isTrashMode(proxy)) {
        return proxy.__cfibOriginalHandleBatchDelete.apply(proxy, arguments);
      }

      var selected = Array.isArray(proxy.selectedFiles) ? proxy.selectedFiles.filter(function (file) {
        return file && !file.isFolder;
      }) : [];
      if (!selected.length) {
        showToast(text("selectFilesFirst"), "error");
        return;
      }
      if (!window.confirm(text("permanentDelete") + ": " + selected.length)) return;

      Promise.all(selected.map(function (file) {
        return apiJson("/api/manage/delete/" + encodeManagePath(file.name) + "?permanent=true", { method: "DELETE" });
      })).then(function () {
        proxy.selectedFiles = [];
        return proxy.refreshFileList();
      }).catch(function (error) {
        showToast(error.message || String(error), "error");
      });
    };
  }

  function restoreSelectedTrashFiles() {
    var proxy = findDashboardProxy();
    if (!proxy || !isTrashMode(proxy)) {
      showToast(text("dashboardUnavailable"), "error");
      return;
    }

    patchDashboardTrashDelete(proxy);
    var selected = Array.isArray(proxy.selectedFiles) ? proxy.selectedFiles.filter(function (file) {
      return file && !file.isFolder;
    }) : [];
    if (!selected.length) {
      showToast(text("selectFilesFirst"), "error");
      return;
    }

    Promise.all(selected.map(function (file) {
      return apiJson("/api/manage/trash/restore/" + encodeManagePath(file.name), { method: "POST" });
    })).then(function () {
      showToast(text("restoreDone") + ": " + selected.length, "success");
      proxy.selectedFiles = [];
      return proxy.refreshFileList();
    }).catch(function (error) {
      showToast(error.message || String(error), "error");
    });
  }

  function ensureModal() {
    var modal = document.querySelector(".cfib-modal");
    if (modal) return modal;

    modal = document.createElement("div");
    modal.className = "cfib-modal";
    modal.innerHTML =
      '<div class="cfib-modal-backdrop" data-modal-close="true"></div>' +
      '<section class="cfib-modal-panel" role="dialog" aria-modal="true">' +
      '<header class="cfib-modal-header">' +
      '<h2 class="cfib-modal-title"></h2>' +
      '<button class="cfib-modal-close" type="button" data-modal-close="true" aria-label="' + escapeHtml(text("close")) + '">×</button>' +
      '</header>' +
      '<div class="cfib-modal-body"></div>' +
      '</section>';

    modal.addEventListener("click", function (event) {
      if (event.target && event.target.dataset.modalClose === "true") {
        closeModal();
      }
    });
    document.body.appendChild(modal);
    return modal;
  }

  function showModal(title, content) {
    var modal = ensureModal();
    modal.querySelector(".cfib-modal-title").textContent = title;
    modal.querySelector(".cfib-modal-body").innerHTML = content;
    modal.classList.add("is-open");
  }

  function closeModal() {
    var modal = document.querySelector(".cfib-modal");
    if (modal) modal.classList.remove("is-open");
  }

  function showLoading(title) {
    showModal(title, '<div class="cfib-modal-state">' + escapeHtml(text("loading")) + '</div>');
  }

  function apiJson(url, options) {
    return fetch(url, Object.assign({
      credentials: "include",
      headers: { "Content-Type": "application/json" }
    }, options || {})).then(function (response) {
      return response.json().catch(function () {
        return {};
      }).then(function (data) {
        if (!response.ok || data.success === false) {
          throw new Error(data.error || data.message || response.statusText);
        }
        return data;
      });
    });
  }

  function openTrashModal() {
    showLoading(text("trash"));
    loadTrashFiles();
  }

  function loadTrashFiles() {
    apiJson("/api/manage/list?listType=Trash&count=-1&recursive=true")
      .then(function (data) {
        renderTrashFiles(data.files || []);
      })
      .catch(function (error) {
        renderError(text("trash"), error);
      });
  }

  function renderTrashFiles(files) {
    var html = '<div class="cfib-modal-toolbar"><button class="cfib-secondary-btn" type="button" data-trash-action="refresh">' + escapeHtml(text("refresh")) + '</button></div>';
    html += renderFileList(files, function (file) {
      var filePath = encodeFilePath(file.name);
      return '<button class="cfib-secondary-btn" type="button" data-trash-action="restore" data-file="' + escapeHtml(file.name) + '">' + escapeHtml(text("restore")) + '</button>' +
        '<button class="cfib-danger-btn" type="button" data-trash-action="permanent" data-file="' + escapeHtml(file.name) + '">' + escapeHtml(text("permanentDelete")) + '</button>' +
        '<a class="cfib-secondary-btn" href="/file/' + filePath + '?from=admin" target="_blank" rel="noreferrer">' + escapeHtml(text("open")) + '</a>';
    });
    showModal(text("trash"), html);

    var modal = ensureModal();
    modal.querySelectorAll("[data-trash-action]").forEach(function (button) {
      button.addEventListener("click", function () {
        var action = button.dataset.trashAction;
        if (action === "refresh") {
          loadTrashFiles();
          return;
        }

        var fileId = button.dataset.file;
        if (action === "restore") {
          restoreTrashFile(fileId);
        } else if (action === "permanent") {
          permanentDeleteFile(fileId);
        }
      });
    });
  }

  function restoreTrashFile(fileId) {
    apiJson("/api/manage/trash/restore/" + encodeManagePath(fileId), { method: "POST" })
      .then(loadTrashFiles)
      .catch(function (error) {
        renderError(text("trash"), error);
      });
  }

  function permanentDeleteFile(fileId) {
    if (!window.confirm(text("permanentDelete") + ": " + fileId)) return;
    apiJson("/api/manage/delete/" + encodeManagePath(fileId) + "?permanent=true", { method: "DELETE" })
      .then(loadTrashFiles)
      .catch(function (error) {
        renderError(text("trash"), error);
      });
  }

  function importTelegramUpdates() {
    showToast(text("importingTelegram"), "loading");
    apiJson("/api/manage/telegram/import", { method: "POST", body: JSON.stringify({}) })
      .then(function (data) {
        var imported = data.imported ? data.imported.length : 0;
        var skipped = data.skipped ? data.skipped.length : 0;
        var failed = data.failed ? data.failed.length : 0;
        showToast(
          text("importDone") + " - " + text("imported") + ": " + imported + ", " + text("skipped") + ": " + skipped + ", " + text("failed") + ": " + failed,
          failed > 0 ? "error" : "success"
        );
        if (!refreshDashboardIfReady()) {
          markDashboardRefreshPending();
        }
      })
      .catch(function (error) {
        showToast(error.message || String(error), "error");
      });
  }

  function ensureToastContainer() {
    var container = document.querySelector(".cfib-toast-container");
    if (container) return container;
    container = document.createElement("div");
    container.className = "cfib-toast-container";
    document.body.appendChild(container);
    return container;
  }

  function showToast(message, type) {
    var container = ensureToastContainer();
    var toast = document.createElement("div");
    toast.className = "cfib-toast " + (type || "info");
    toast.textContent = message;
    container.appendChild(toast);
    window.setTimeout(function () {
      toast.classList.add("is-leaving");
      window.setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 220);
    }, type === "loading" ? 1800 : 3600);
  }
  function renderFileList(files, actionRenderer) {
    if (!files.length) {
      return '<div class="cfib-modal-state">' + escapeHtml(text("noFiles")) + '</div>';
    }

    return '<div class="cfib-file-list">' + files.map(function (file) {
      var metadata = file.metadata || {};
      var tags = Array.isArray(metadata.Tags) && metadata.Tags.length
        ? '<div class="cfib-file-tags">' + metadata.Tags.map(function (tag) {
          return '<span>' + escapeHtml(tag) + '</span>';
        }).join("") + '</div>'
        : '';
      return '<article class="cfib-file-row">' +
        '<div class="cfib-file-main">' +
        '<strong>' + escapeHtml(metadata.FileName || file.name) + '</strong>' +
        '<span>' + escapeHtml(file.name) + '</span>' +
        tags +
        '</div>' +
        '<div class="cfib-file-actions">' + actionRenderer(file) + '</div>' +
        '</article>';
    }).join("") + '</div>';
  }

  function renderResultList(items, key) {
    if (!items.length) return "";
    return '<div class="cfib-result-list">' + items.map(function (item) {
      return '<div><strong>' + escapeHtml(item.channelName || "") + '</strong><span>' + escapeHtml(item[key] || item.messageId || "") + '</span></div>';
    }).join("") + '</div>';
  }

  function renderError(title, error) {
    showModal(title, '<div class="cfib-modal-error">' + escapeHtml(error.message || String(error)) + '</div>');
  }

  function summaryPill(label, value) {
    return '<span><strong>' + Number(value || 0) + '</strong>' + escapeHtml(label) + '</span>';
  }

  function encodeManagePath(fileId) {
    return encodeURIComponent(String(fileId || "").split("/").join(","));
  }

  function encodeFilePath(fileId) {
    return String(fileId || "").split("/").map(encodeURIComponent).join("/");
  }

  function updateAdminActions(nav) {
    var proxy = findDashboardProxy();
    var trashMode = normalizedPath() === "/dashboard" && (currentDashboardMode === "trash" || isTrashMode(proxy) || pendingDashboardMode === "trash" || getSessionValue(dashboardModeStorageKey) === "trash");

    if (proxy) {
      patchDashboardTrashDelete(proxy);
      patchDashboardModeRefresh(proxy);
    }

    nav.querySelectorAll("[data-admin-action]").forEach(function (button) {
      var action = button.dataset.adminAction;
      button.title = text(action);
      button.setAttribute("aria-label", text(action));
      button.classList.toggle("is-active", action === "trash" && trashMode);
    });
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function ensureUploadNav() {
    var existing = document.querySelector(".cfib-upload-nav");
    if (normalizedPath() !== "/") {
      if (existing) existing.remove();
      return;
    }

    var host = document.querySelector(".upload-home");
    if (!host) return;

    if (!existing) {
      existing = makeNav("cfib-upload-nav", true);
      host.appendChild(existing);
    }
    updateNav(existing);
  }

  function ensureTabsUnifiedLayout(tabs, nav) {
    tabs.classList.add("cfib-tabs-hotfix", "cfib-tabs-unified");

    var tools = tabs.querySelector(".cfib-tabs-tools");
    if (!tools) {
      tools = document.createElement("div");
      tools.className = "cfib-tabs-tools";
      tabs.insertBefore(tools, tabs.firstChild);
    }

    var themeToggle = tabs.querySelector("#themeToggle");
    var languageSwitcher = tabs.querySelector(".tabs-language-switcher");
    [themeToggle, languageSwitcher].forEach(function (node) {
      if (node && node.parentNode !== tools) {
        tools.appendChild(node);
      }
    });

    if (nav && nav.parentNode !== tabs) {
      tabs.appendChild(nav);
    }
  }

  function ensureAdminNav() {
    var tabs = document.querySelector(".tabs");
    var pageSwitcher = tabs && tabs.querySelector(".page-switcher");
    if (!tabs || !pageSwitcher) return;

    tabs.classList.add("cfib-tabs-hotfix", "cfib-tabs-unified");
    var nav = tabs.querySelector(".cfib-admin-nav");
    if (!nav) {
      nav = makeNav("cfib-admin-nav", false);
      tabs.insertBefore(nav, pageSwitcher);
    }
    ensureTabsUnifiedLayout(tabs, nav);
    if (!nav.querySelector(".cfib-admin-actions")) {
      nav.appendChild(makeAdminActions());
    }
    updateNav(nav);
    updateAdminActions(nav);
  }

  function refresh() {
    ensureUploadNav();
    applyPendingDashboardMode();
    flushPendingDashboardRefresh();
    enforceDashboardModeRefresh();
    ensureDashboardFileActions();
    ensureAdminNav();
    document.querySelectorAll(".cfib-main-nav").forEach(updateNav);
  }

  var pending = 0;
  function scheduleRefresh() {
    if (pending) return;
    pending = window.requestAnimationFrame(function () {
      pending = 0;
      refresh();
    });
  }

  ["pushState", "replaceState"].forEach(function (method) {
    var original = history[method];
    history[method] = function () {
      var result = original.apply(this, arguments);
      scheduleRefresh();
      return result;
    };
  });

  document.addEventListener("click", closeActionMenus);
  window.addEventListener("resize", positionOpenActionMenus);
  window.addEventListener("scroll", positionOpenActionMenus, true);
  window.addEventListener("popstate", scheduleRefresh);
  window.addEventListener("storage", scheduleRefresh);
  new MutationObserver(scheduleRefresh).observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", refresh);
  } else {
    refresh();
  }
})();
